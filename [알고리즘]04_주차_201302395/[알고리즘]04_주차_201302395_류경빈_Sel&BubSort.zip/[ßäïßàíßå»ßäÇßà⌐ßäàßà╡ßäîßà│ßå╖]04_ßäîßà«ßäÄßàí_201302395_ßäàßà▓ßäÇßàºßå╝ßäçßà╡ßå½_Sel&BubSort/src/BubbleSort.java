import java.util.ArrayList;

public class BubbleSort {
    private ArrayList<Integer> array;

    public BubbleSort(ArrayList<Integer> array){
        this.array = array;
    }

    public void doBubbleSort(){
        int temp = 0;
        for (int i = array.size()-1; i>=0; i--){
            for (int j=0; j<i; j++){
                if (array.get(j) > array.get(j+1)){
                    temp = array.get(j);
                    array.set(j, array.get(j+1));
                    array.set(j+1, temp);
                }
            }
        }
    }

    public ArrayList<Integer> getArray(){
        return this.array;
    }

}

